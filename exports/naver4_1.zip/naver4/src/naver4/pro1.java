package naver4;


import java.util.*;

public class pro1 {

	public static void main(String[] args) {
		Max<Number> n = new Max<>();
		System.out.println(n.Max());
		
		
	}
	public static class Max<t> {
		public <T> T Max(Object obj1,Object obj2) {
			
			return ();
		}
	}
}
